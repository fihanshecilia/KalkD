package com.fihan.kalkd.database

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "siswa_data")
data class SiswaEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Int = 0,

    @ColumnInfo(name = "nama")
    val nama: String,

    @ColumnInfo(name = "kelas")
    val kelas: String,

    @ColumnInfo(name = "jurusan")
    val jurusan: String,

    @ColumnInfo(name = "nilai")
    val nilai: Double
)