package com.fihan.kalkd.fragment

import android.app.AlertDialog
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.activity.result.ActivityResultLauncher
import androidx.activity.result.contract.ActivityResultContracts
import androidx.fragment.app.Fragment
import com.fihan.kalkd.LoginActivity
import com.fihan.kalkd.R
import com.fihan.kalkd.databinding.DialogEditProfileBinding
import com.fihan.kalkd.databinding.FragmentProfileBinding
import com.fihan.kalkd.util.SessionManager

class ProfileFragment : Fragment() {

    private var _binding: FragmentProfileBinding? = null
    private val binding get() = _binding!!
    private lateinit var sessionManager: SessionManager

    private val selectImageLauncher: ActivityResultLauncher<String> =
        registerForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
            uri?.let {
                binding.imgProfile.setImageURI(it)
                sessionManager.saveImageUri(it.toString())
                Toast.makeText(requireContext(), "Foto profil berhasil diperbarui", Toast.LENGTH_SHORT).show()
            }
        }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentProfileBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        sessionManager = SessionManager(requireContext())

        displayUserData()

        binding.fabChangePhoto.setOnClickListener {
            selectImageLauncher.launch("image/*")
        }

        binding.btnEditProfile.setOnClickListener {
            showEditProfileDialog()
        }

        binding.btnLogout.setOnClickListener {
            showLogoutConfirmation()
        }
    }

    private fun displayUserData() {
        binding.tvProfileNama.text = sessionManager.getNama()
        binding.tvProfileUsername.text = "@" + sessionManager.getUsername()
        binding.tvProfileEmail.text = sessionManager.getEmail()
        binding.tvProfileKelas.text = sessionManager.getKelas()
        binding.tvProfileJurusan.text = sessionManager.getJurusan()

        val savedImageUri = sessionManager.getImageUri()
        if (!savedImageUri.isNullOrEmpty()) {
            try {
                binding.imgProfile.setImageURI(Uri.parse(savedImageUri))
            } catch (e: Exception) {
                binding.imgProfile.setImageResource(R.drawable.ic_person)
            }
        } else {
            binding.imgProfile.setImageResource(R.drawable.ic_person)
        }
    }

    private fun showEditProfileDialog() {
        val dialogBinding = DialogEditProfileBinding.inflate(layoutInflater)
        dialogBinding.etEditNama.setText(sessionManager.getNama())
        dialogBinding.etEditKelas.setText(sessionManager.getKelas())
        dialogBinding.etEditJurusan.setText(sessionManager.getJurusan())

        val alertDialog = AlertDialog.Builder(requireContext())
            .setView(dialogBinding.root)
            .setPositiveButton(getString(R.string.simpan), null)
            .setNegativeButton(getString(R.string.batal)) { dialog, _ ->
                dialog.dismiss()
            }
            .create()

        alertDialog.setOnShowListener {
            val buttonSimpan = alertDialog.getButton(AlertDialog.BUTTON_POSITIVE)
            buttonSimpan.setOnClickListener {
                val nama = dialogBinding.etEditNama.text.toString().trim()
                val kelas = dialogBinding.etEditKelas.text.toString().trim()
                val jurusan = dialogBinding.etEditJurusan.text.toString().trim()

                var valid = true

                if (nama.isEmpty()) {
                    dialogBinding.tilEditNama.error = getString(R.string.err_empty_field)
                    valid = false
                } else {
                    dialogBinding.tilEditNama.error = null
                }

                if (kelas.isEmpty()) {
                    dialogBinding.tilEditKelas.error = getString(R.string.err_empty_field)
                    valid = false
                } else {
                    dialogBinding.tilEditKelas.error = null
                }

                if (jurusan.isEmpty()) {
                    dialogBinding.tilEditJurusan.error = getString(R.string.err_empty_field)
                    valid = false
                } else {
                    dialogBinding.tilEditJurusan.error = null
                }

                if (valid) {
                    sessionManager.updateProfile(nama, kelas, jurusan)
                    displayUserData()
                    Toast.makeText(requireContext(), "Profil berhasil diperbarui", Toast.LENGTH_SHORT).show()
                    alertDialog.dismiss()
                }
            }
        }

        alertDialog.show()
    }

    private fun showLogoutConfirmation() {
        AlertDialog.Builder(requireContext())
            .setTitle(getString(R.string.btn_logout))
            .setMessage(getString(R.string.konfirmasi_logout))
            .setPositiveButton("Ya, Logout") { dialog, _ ->
                sessionManager.logout()
                Toast.makeText(requireContext(), "Berhasil logout", Toast.LENGTH_SHORT).show()

                val intent = Intent(requireContext(), LoginActivity::class.java).apply {
                    flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
                }
                startActivity(intent)
                requireActivity().finish()
                dialog.dismiss()
            }
            .setNegativeButton(getString(R.string.batal)) { dialog, _ ->
                dialog.dismiss()
            }
            .show()
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}