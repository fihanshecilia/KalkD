package com.fihan.kalkd.fragment

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import com.fihan.kalkd.adapter.UserApiAdapter
import com.fihan.kalkd.api.RetrofitClient
import com.fihan.kalkd.api.UserApi
import com.fihan.kalkd.databinding.FragmentWebApiBinding
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class WebApiFragment : Fragment() {

    private var _binding: FragmentWebApiBinding? = null
    private val binding get() = _binding!!
    private lateinit var userApiAdapter: UserApiAdapter

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentWebApiBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        setupRecyclerView()
        fetchDataUsers()

        binding.btnRetryApi.setOnClickListener {
            fetchDataUsers()
        }
    }

    private fun setupRecyclerView() {
        userApiAdapter = UserApiAdapter(mutableListOf())
        binding.rvUsersApi.apply {
            layoutManager = LinearLayoutManager(requireContext())
            adapter = userApiAdapter
        }
    }

    private fun fetchDataUsers() {
        binding.progressBarApi.visibility = View.VISIBLE
        binding.tvErrorApi.visibility = View.GONE
        binding.btnRetryApi.visibility = View.GONE
        binding.rvUsersApi.visibility = View.GONE

        RetrofitClient.instance.getUsers().enqueue(object : Callback<List<UserApi>> {
            override fun onResponse(
                call: Call<List<UserApi>>,
                response: Response<List<UserApi>>
            ) {
                if (_binding == null) return

                binding.progressBarApi.visibility = View.GONE

                if (response.isSuccessful && response.body() != null) {
                    val users = response.body()!!
                    userApiAdapter.updateData(users)
                    binding.rvUsersApi.visibility = View.VISIBLE
                } else {
                    binding.tvErrorApi.text = "Gagal memuat data (Kode: " + response.code() + ")"
                    binding.tvErrorApi.visibility = View.VISIBLE
                    binding.btnRetryApi.visibility = View.VISIBLE
                }
            }

            override fun onFailure(call: Call<List<UserApi>>, t: Throwable) {
                if (_binding == null) return

                binding.progressBarApi.visibility = View.GONE
                binding.tvErrorApi.text = "Koneksi gagal: " + (t.localizedMessage ?: "Periksa koneksi internet Anda")
                binding.tvErrorApi.visibility = View.VISIBLE
                binding.btnRetryApi.visibility = View.VISIBLE
            }
        })
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}