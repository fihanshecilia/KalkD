package com.fihan.kalkd.fragment

import android.app.AlertDialog
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import com.fihan.kalkd.R
import com.fihan.kalkd.adapter.SiswaAdapter
import com.fihan.kalkd.database.AppDatabase
import com.fihan.kalkd.database.SiswaEntity
import com.fihan.kalkd.databinding.DialogAddEditSiswaBinding
import com.fihan.kalkd.databinding.FragmentDataBinding
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class DataFragment : Fragment() {

    private var _binding: FragmentDataBinding? = null
    private val binding get() = _binding!!

    private lateinit var appDatabase: AppDatabase
    private lateinit var siswaAdapter: SiswaAdapter

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentDataBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        appDatabase = AppDatabase.getDatabase(requireContext())

        setupRecyclerView()
        checkAndSeedInitialData()

        binding.fabTambahSiswa.setOnClickListener {
            showAddEditDialog(null)
        }
    }

    private fun setupRecyclerView() {
        siswaAdapter = SiswaAdapter(
            mutableListOf(),
            onEditClick = { siswa -> showAddEditDialog(siswa) },
            onDeleteClick = { siswa -> showDeleteConfirmation(siswa) }
        )

        binding.rvSiswa.apply {
            layoutManager = LinearLayoutManager(requireContext())
            adapter = siswaAdapter
        }
    }

    private fun checkAndSeedInitialData() {
        lifecycleScope.launch(Dispatchers.IO) {
            val count = appDatabase.siswaDao().getCount()
            if (count == 0) {
                val dummy1 = SiswaEntity(
                    nama = "Ahmad Fauzi",
                    kelas = "XII RPL 1",
                    jurusan = "Rekayasa Perangkat Lunak",
                    nilai = 92.5
                )
                val dummy2 = SiswaEntity(
                    nama = "Siti Nurhaliza",
                    kelas = "XII RPL 2",
                    jurusan = "Rekayasa Perangkat Lunak",
                    nilai = 88.0
                )
                val dummy3 = SiswaEntity(
                    nama = "Budi Santoso",
                    kelas = "XII TKJ 1",
                    jurusan = "Teknik Komputer dan Jaringan",
                    nilai = 85.0
                )

                appDatabase.siswaDao().insertData(dummy1)
                appDatabase.siswaDao().insertData(dummy2)
                appDatabase.siswaDao().insertData(dummy3)
            }

            loadData()
        }
    }

    private fun loadData() {
        lifecycleScope.launch(Dispatchers.IO) {
            val dataList = appDatabase.siswaDao().getAllData()
            withContext(Dispatchers.Main) {
                siswaAdapter.updateData(dataList)
                binding.tvJumlahData.text = "Total: ${dataList.size} Siswa Terdaftar"
                if (dataList.isEmpty()) {
                    binding.tvEmptyState.visibility = View.VISIBLE
                    binding.rvSiswa.visibility = View.GONE
                } else {
                    binding.tvEmptyState.visibility = View.GONE
                    binding.rvSiswa.visibility = View.VISIBLE
                }
            }
        }
    }

    private fun showAddEditDialog(siswa: SiswaEntity?) {
        val dialogBinding = DialogAddEditSiswaBinding.inflate(layoutInflater)
        val isEdit = siswa != null

        if (isEdit) {
            dialogBinding.tvDialogTitle.text = getString(R.string.edit_siswa)
            dialogBinding.etDialogNama.setText(siswa!!.nama)
            dialogBinding.etDialogKelas.setText(siswa.kelas)
            dialogBinding.etDialogJurusan.setText(siswa.jurusan)
            dialogBinding.etDialogNilai.setText(siswa.nilai.toString())
        } else {
            dialogBinding.tvDialogTitle.text = getString(R.string.tambah_siswa)
        }

        val alertDialog = AlertDialog.Builder(requireContext())
            .setView(dialogBinding.root)
            .setPositiveButton(getString(R.string.simpan), null)
            .setNegativeButton(getString(R.string.batal)) { dialog, _ ->
                dialog.dismiss()
            }
            .create()

        alertDialog.setOnShowListener {
            val buttonSimpan = alertDialog.getButton(AlertDialog.BUTTON_POSITIVE)
            buttonSimpan.setOnClickListener {
                val nama = dialogBinding.etDialogNama.text.toString().trim()
                val kelas = dialogBinding.etDialogKelas.text.toString().trim()
                val jurusan = dialogBinding.etDialogJurusan.text.toString().trim()
                val nilaiStr = dialogBinding.etDialogNilai.text.toString().trim()

                var valid = true

                if (nama.isEmpty()) {
                    dialogBinding.tilDialogNama.error = getString(R.string.err_empty_field)
                    valid = false
                } else {
                    dialogBinding.tilDialogNama.error = null
                }

                if (kelas.isEmpty()) {
                    dialogBinding.tilDialogKelas.error = getString(R.string.err_empty_field)
                    valid = false
                } else {
                    dialogBinding.tilDialogKelas.error = null
                }

                if (jurusan.isEmpty()) {
                    dialogBinding.tilDialogJurusan.error = getString(R.string.err_empty_field)
                    valid = false
                } else {
                    dialogBinding.tilDialogJurusan.error = null
                }

                val nilai = nilaiStr.toDoubleOrNull()
                if (nilaiStr.isEmpty() || nilai == null || nilai < 0 || nilai > 100) {
                    dialogBinding.tilDialogNilai.error = "Masukkan nilai valid (0 - 100)"
                    valid = false
                } else {
                    dialogBinding.tilDialogNilai.error = null
                }

                if (valid && nilai != null) {
                    lifecycleScope.launch(Dispatchers.IO) {
                        if (isEdit) {
                            val updatedSiswa = SiswaEntity(
                                id = siswa!!.id,
                                nama = nama,
                                kelas = kelas,
                                jurusan = jurusan,
                                nilai = nilai
                            )
                            appDatabase.siswaDao().updateData(updatedSiswa)
                        } else {
                            val newSiswa = SiswaEntity(
                                nama = nama,
                                kelas = kelas,
                                jurusan = jurusan,
                                nilai = nilai
                            )
                            appDatabase.siswaDao().insertData(newSiswa)
                        }

                        withContext(Dispatchers.Main) {
                            Toast.makeText(
                                requireContext(),
                                if (isEdit) "Data siswa berhasil diubah" else "Data siswa berhasil ditambahkan",
                                Toast.LENGTH_SHORT
                            ).show()
                            loadData()
                            alertDialog.dismiss()
                        }
                    }
                }
            }
        }

        alertDialog.show()
    }

    private fun showDeleteConfirmation(siswa: SiswaEntity) {
        AlertDialog.Builder(requireContext())
            .setTitle(getString(R.string.hapus))
            .setMessage(getString(R.string.konfirmasi_hapus) + "\n\n" + siswa.nama)
            .setPositiveButton(getString(R.string.hapus)) { dialog, _ ->
                lifecycleScope.launch(Dispatchers.IO) {
                    appDatabase.siswaDao().deleteData(siswa)
                    withContext(Dispatchers.Main) {
                        Toast.makeText(requireContext(), "Data berhasil dihapus", Toast.LENGTH_SHORT).show()
                        loadData()
                    }
                }
                dialog.dismiss()
            }
            .setNegativeButton(getString(R.string.batal)) { dialog, _ ->
                dialog.dismiss()
            }
            .show()
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}