package com.fihan.kalkd.fragment

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.Fragment
import com.fihan.kalkd.R
import com.fihan.kalkd.databinding.FragmentKalkulatorBinding
import java.text.DecimalFormat

class KalkulatorFragment : Fragment() {

    private var _binding: FragmentKalkulatorBinding? = null
    private val binding get() = _binding!!
    private val decimalFormat = DecimalFormat("#.######")

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentKalkulatorBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        binding.btnTambah.setOnClickListener { hitung('+') }
        binding.btnKurang.setOnClickListener { hitung('-') }
        binding.btnKali.setOnClickListener { hitung('*') }
        binding.btnBagi.setOnClickListener { hitung('/') }

        binding.btnReset.setOnClickListener {
            binding.etAngka1.text?.clear()
            binding.etAngka2.text?.clear()
            binding.tvHasil.text = "0"
            binding.tilAngka1.error = null
            binding.tilAngka2.error = null
        }
    }

    private fun hitung(operasi: Char) {
        val strAngka1 = binding.etAngka1.text.toString().trim()
        val strAngka2 = binding.etAngka2.text.toString().trim()

        var isValid = true

        if (strAngka1.isEmpty()) {
            binding.tilAngka1.error = getString(R.string.err_empty_field)
            isValid = false
        } else {
            binding.tilAngka1.error = null
        }

        if (strAngka2.isEmpty()) {
            binding.tilAngka2.error = getString(R.string.err_empty_field)
            isValid = false
        } else {
            binding.tilAngka2.error = null
        }

        if (!isValid) {
            Toast.makeText(requireContext(), getString(R.string.err_input_empty), Toast.LENGTH_SHORT).show()
            return
        }

        val angka1 = strAngka1.toDoubleOrNull()
        val angka2 = strAngka2.toDoubleOrNull()

        if (angka1 == null || angka2 == null) {
            Toast.makeText(requireContext(), "Input angka tidak valid", Toast.LENGTH_SHORT).show()
            return
        }

        when (operasi) {
            '+' -> {
                val hasil = angka1 + angka2
                binding.tvHasil.text = decimalFormat.format(hasil)
            }
            '-' -> {
                val hasil = angka1 - angka2
                binding.tvHasil.text = decimalFormat.format(hasil)
            }
            '*' -> {
                val hasil = angka1 * angka2
                binding.tvHasil.text = decimalFormat.format(hasil)
            }
            '/' -> {
                if (angka2 == 0.0) {
                    binding.tilAngka2.error = getString(R.string.err_division_by_zero)
                    Toast.makeText(requireContext(), getString(R.string.err_division_by_zero), Toast.LENGTH_LONG).show()
                    binding.tvHasil.text = "Error"
                } else {
                    val hasil = angka1 / angka2
                    binding.tvHasil.text = decimalFormat.format(hasil)
                }
            }
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}