package com.fihan.kalkd.fragment

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import com.fihan.kalkd.R
import com.fihan.kalkd.databinding.FragmentHomeBinding
import com.fihan.kalkd.util.SessionManager

class HomeFragment : Fragment() {

    private var _binding: FragmentHomeBinding? = null
    private val binding get() = _binding!!
    private lateinit var sessionManager: SessionManager

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentHomeBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        sessionManager = SessionManager(requireContext())

        val nama = sessionManager.getNama()
        val kelas = sessionManager.getKelas()
        val jurusan = sessionManager.getJurusan()

        binding.tvGreeting.text = getString(R.string.welcome_greeting)
        binding.tvUserName.text = if (nama.isNotEmpty()) nama else "Pengguna KalkD"
        binding.tvUserKelasJurusan.text = "$kelas | $jurusan"

        binding.cardFiturKalkulator.setOnClickListener {
            parentFragmentManager.beginTransaction()
                .replace(R.id.fragment_container, KalkulatorFragment())
                .commit()
        }

        binding.cardFiturData.setOnClickListener {
            parentFragmentManager.beginTransaction()
                .replace(R.id.fragment_container, DataFragment())
                .commit()
        }

        binding.cardFiturApi.setOnClickListener {
            parentFragmentManager.beginTransaction()
                .replace(R.id.fragment_container, WebApiFragment())
                .commit()
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}