package com.fihan.kalkd.util

import android.content.Context
import android.content.SharedPreferences

class SessionManager(context: Context) {

    private val pref: SharedPreferences =
        context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
    private val editor: SharedPreferences.Editor = pref.edit()

    companion object {
        private const val PREF_NAME = "KalkDSessionPref"
        private const val IS_LOGGED_IN = "isLoggedIn"
        private const val KEY_USERNAME = "username"
        private const val KEY_EMAIL = "email"
        private const val KEY_NAMA = "nama"
        private const val KEY_KELAS = "kelas"
        private const val KEY_JURUSAN = "jurusan"
        private const val KEY_IMAGE_URI = "imageUri"
    }

    fun saveUser(
        username: String,
        email: String,
        nama: String,
        kelas: String,
        jurusan: String
    ) {
        editor.putBoolean(IS_LOGGED_IN, true)
        editor.putString(KEY_USERNAME, username)
        editor.putString(KEY_EMAIL, email)
        editor.putString(KEY_NAMA, nama)
        editor.putString(KEY_KELAS, kelas)
        editor.putString(KEY_JURUSAN, jurusan)
        editor.apply()
    }

    fun updateProfile(nama: String, kelas: String, jurusan: String) {
        editor.putString(KEY_NAMA, nama)
        editor.putString(KEY_KELAS, kelas)
        editor.putString(KEY_JURUSAN, jurusan)
        editor.apply()
    }

    fun saveImageUri(uriString: String) {
        editor.putString(KEY_IMAGE_URI, uriString)
        editor.apply()
    }

    fun getImageUri(): String? {
        return pref.getString(KEY_IMAGE_URI, null)
    }

    fun isLoggedIn(): Boolean {
        return pref.getBoolean(IS_LOGGED_IN, false)
    }

    fun getUsername(): String {
        return pref.getString(KEY_USERNAME, "") ?: ""
    }

    fun getEmail(): String {
        return pref.getString(KEY_EMAIL, "") ?: ""
    }

    fun getNama(): String {
        return pref.getString(KEY_NAMA, "") ?: ""
    }

    fun getKelas(): String {
        return pref.getString(KEY_KELAS, "") ?: ""
    }

    fun getJurusan(): String {
        return pref.getString(KEY_JURUSAN, "") ?: ""
    }

    fun logout() {
        editor.clear()
        editor.apply()
    }
}