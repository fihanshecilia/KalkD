package com.fihan.kalkd.adapter

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.fihan.kalkd.database.SiswaEntity
import com.fihan.kalkd.databinding.ItemSiswaBinding

class SiswaAdapter(
    private var listSiswa: MutableList<SiswaEntity>,
    private val onEditClick: (SiswaEntity) -> Unit,
    private val onDeleteClick: (SiswaEntity) -> Unit
) : RecyclerView.Adapter<SiswaAdapter.SiswaViewHolder>() {

    inner class SiswaViewHolder(private val binding: ItemSiswaBinding) :
        RecyclerView.ViewHolder(binding.root) {

        fun bind(siswa: SiswaEntity) {
            binding.tvItemNama.text = siswa.nama
            binding.tvItemKelas.text = "Kelas: " + siswa.kelas
            binding.tvItemJurusan.text = "Jurusan: " + siswa.jurusan
            binding.tvItemNilaiBadge.text = "Nilai: " + siswa.nilai.toString()

            binding.btnEditSiswa.setOnClickListener {
                onEditClick(siswa)
            }

            binding.btnHapusSiswa.setOnClickListener {
                onDeleteClick(siswa)
            }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): SiswaViewHolder {
        val binding = ItemSiswaBinding.inflate(
            LayoutInflater.from(parent.context),
            parent,
            false
        )
        return SiswaViewHolder(binding)
    }

    override fun onBindViewHolder(holder: SiswaViewHolder, position: Int) {
        holder.bind(listSiswa[position])
    }

    override fun getItemCount(): Int = listSiswa.size

    fun updateData(newList: List<SiswaEntity>) {
        listSiswa.clear()
        listSiswa.addAll(newList)
        notifyDataSetChanged()
    }
}