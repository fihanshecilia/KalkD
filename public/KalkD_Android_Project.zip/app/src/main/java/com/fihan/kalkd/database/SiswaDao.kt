package com.fihan.kalkd.database

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update

@Dao
interface SiswaDao {

    @Query("SELECT * FROM siswa_data ORDER BY id DESC")
    suspend fun getAllData(): List<SiswaEntity>

    @Query("SELECT COUNT(*) FROM siswa_data")
    suspend fun getCount(): Int

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertData(siswa: SiswaEntity): Long

    @Update
    suspend fun updateData(siswa: SiswaEntity)

    @Delete
    suspend fun deleteData(siswa: SiswaEntity)
}