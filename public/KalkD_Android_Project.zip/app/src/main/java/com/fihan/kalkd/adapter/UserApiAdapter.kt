package com.fihan.kalkd.adapter

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.fihan.kalkd.api.UserApi
import com.fihan.kalkd.databinding.ItemUserApiBinding

class UserApiAdapter(
    private var listUser: MutableList<UserApi>
) : RecyclerView.Adapter<UserApiAdapter.UserViewHolder>() {

    inner class UserViewHolder(private val binding: ItemUserApiBinding) :
        RecyclerView.ViewHolder(binding.root) {

        fun bind(user: UserApi) {
            binding.tvApiUserName.text = user.name
            binding.tvApiUserUsername.text = "@" + user.username
            binding.tvApiUserEmail.text = "Email: " + user.email
            binding.tvApiUserPhone.text = "Telepon: " + user.phone
            binding.tvApiUserCompany.text = "Perusahaan: " + user.company.name
            binding.tvApiUserCity.text = "Kota: " + user.address.city
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): UserViewHolder {
        val binding = ItemUserApiBinding.inflate(
            LayoutInflater.from(parent.context),
            parent,
            false
        )
        return UserViewHolder(binding)
    }

    override fun onBindViewHolder(holder: UserViewHolder, position: Int) {
        holder.bind(listUser[position])
    }

    override fun getItemCount(): Int = listUser.size

    fun updateData(newList: List<UserApi>) {
        listUser.clear()
        listUser.addAll(newList)
        notifyDataSetChanged()
    }
}