package com.fihan.kalkd

import android.content.Intent
import android.os.Bundle
import android.util.Patterns
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.fihan.kalkd.databinding.ActivityLoginBinding
import com.fihan.kalkd.util.SessionManager

class LoginActivity : AppCompatActivity() {

    private lateinit var binding: ActivityLoginBinding
    private lateinit var sessionManager: SessionManager

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityLoginBinding.inflate(layoutInflater)
        setContentView(binding.root)

        sessionManager = SessionManager(this)

        binding.btnLogin.setOnClickListener {
            handleLogin()
        }
    }

    private fun handleLogin() {
        val username = binding.etUsername.text.toString().trim()
        val email = binding.etEmail.text.toString().trim()
        val password = binding.etPassword.text.toString().trim()
        val nama = binding.etNama.text.toString().trim()
        val kelas = binding.etKelas.text.toString().trim()
        val jurusan = binding.etJurusan.text.toString().trim()

        if (username.isEmpty()) {
            binding.tilUsername.error = getString(R.string.err_empty_field)
            binding.etUsername.requestFocus()
            return
        } else {
            binding.tilUsername.error = null
        }

        if (email.isEmpty()) {
            binding.tilEmail.error = getString(R.string.err_empty_field)
            binding.etEmail.requestFocus()
            return
        } else if (!Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
            binding.tilEmail.error = getString(R.string.err_invalid_email)
            binding.etEmail.requestFocus()
            return
        } else {
            binding.tilEmail.error = null
        }

        if (password.isEmpty()) {
            binding.tilPassword.error = getString(R.string.err_empty_field)
            binding.etPassword.requestFocus()
            return
        } else {
            binding.tilPassword.error = null
        }

        if (nama.isEmpty()) {
            binding.tilNama.error = getString(R.string.err_empty_field)
            binding.etNama.requestFocus()
            return
        } else {
            binding.tilNama.error = null
        }

        if (kelas.isEmpty()) {
            binding.tilKelas.error = getString(R.string.err_empty_field)
            binding.etKelas.requestFocus()
            return
        } else {
            binding.tilKelas.error = null
        }

        if (jurusan.isEmpty()) {
            binding.tilJurusan.error = getString(R.string.err_empty_field)
            binding.etJurusan.requestFocus()
            return
        } else {
            binding.tilJurusan.error = null
        }

        sessionManager.saveUser(
            username = username,
            email = email,
            nama = nama,
            kelas = kelas,
            jurusan = jurusan
        )

        Toast.makeText(this, "Login berhasil. Selamat datang, $nama!", Toast.LENGTH_SHORT).show()

        val intent = Intent(this, MainActivity::class.java)
        startActivity(intent)
        finish()
    }
}