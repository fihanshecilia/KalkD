package com.fihan.kalkd

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.Fragment
import com.fihan.kalkd.databinding.ActivityMainBinding
import com.fihan.kalkd.fragment.DataFragment
import com.fihan.kalkd.fragment.HomeFragment
import com.fihan.kalkd.fragment.KalkulatorFragment
import com.fihan.kalkd.fragment.ProfileFragment
import com.fihan.kalkd.fragment.WebApiFragment

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        if (savedInstanceState == null) {
            loadFragment(HomeFragment())
        }

        binding.bottomNavigation.setOnItemSelectedListener { item ->
            when (item.itemId) {
                R.id.nav_home -> {
                    loadFragment(HomeFragment())
                    true
                }
                R.id.nav_kalkulator -> {
                    loadFragment(KalkulatorFragment())
                    true
                }
                R.id.nav_data -> {
                    loadFragment(DataFragment())
                    true
                }
                R.id.nav_api -> {
                    loadFragment(WebApiFragment())
                    true
                }
                R.id.nav_profile -> {
                    loadFragment(ProfileFragment())
                    true
                }
                else -> false
            }
        }
    }

    private fun loadFragment(fragment: Fragment) {
        supportFragmentManager.beginTransaction()
            .replace(R.id.fragment_container, fragment)
            .commit()
    }
}