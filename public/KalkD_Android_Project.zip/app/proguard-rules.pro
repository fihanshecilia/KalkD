# Add project specific ProGuard rules here.
-keep class com.fihan.kalkd.api.** { *; }
-keepclassmembers class * {
    @com.google.gson.annotations.SerializedName <fields>;
}
