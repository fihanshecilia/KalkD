# KalkD - Android Kotlin Project

Aplikasi Android "KalkD" berbasis Kotlin dengan arsitektur MVVM, Room Database (CRUD permanen), Retrofit 2 + Gson, SharedPreferences Session Manager, dan BottomNavigationView 5 menu.

## Kompatibilitas Perangkat
- Min SDK: 24 (Android 7.0 ke atas, mencakup smartphone dan tablet)
- Target SDK: 34 (Android 14)
- Kompatibel penuh untuk instalasi di HP (Smartphone) maupun Tablet Android.

## Cara Menjalankan di Android Studio:
1. Ekstrak file ZIP ini ke folder pilihan Anda.
2. Buka Android Studio (versi Hedgehog, Iguana, Jellyfish, Ladybug, atau terbaru).
3. Pilih menu "Open" lalu pilih folder hasil ekstrak "KalkD".
4. Tunggu proses "Gradle Sync" selesai sampai dependensi terunduh sempurna.
5. Hubungkan HP atau Tablet Android menggunakan kabel USB (aktifkan USB Debugging di Opsi Pengembang HP) atau gunakan Android Virtual Device (Emulator).
6. Klik tombol "Run 'app'" (ikon segitiga hijau) untuk meng-compile dan meng-install aplikasi langsung ke HP/tablet Anda.
